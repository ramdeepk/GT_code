import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MailReader extends Aplication {
	//you must override the start(Stage primaryStage) throws Exception every time!!!!
	//window is a stage, content on the stage is called a scene
	//EX: primaryStage.setTitle("TechMail"); sets title of primaryStage
	//buttons: Button b = new Button(String title); or you can declare a text-less button and use b.setText(String name); <- need three
	//Refresh, [Flag, Trash]-> after clicking
	//before anything will appear on the screen, you must make a layout
	public static void main(String[] args) {
		launch(args);
	}
	
	public void start(Stage primaryStage) throws Exception {
		primaryStage.setTitle("TechMail");
		Button refresh = new Button("Refresh");
		Button flag = new Button("Flag");
		Button trash = new Button("Delete");
		//layout
		StackPane layout = new StackPane();
		layout.setAlignment(BOTTOM_RIGHT);
		layout.getChildren().add(refresh);
		layout.getChildren().add(flag);
		layout.getChildren().add(trash);
		//show
		Scene s = new Scene(layout, 300, 300);
		primaryStage.setScene(s);
		primaryStage.show();
	}
}