import java.util.List;
import java.util.ArrayList;

public class Mailbox {
	
	private String name;
	private Set<Message> messages;
	
	public Mailbox(String name) {
		this.name = name;
		this.messages = new Set<Message>();
	}
	
	public Mailbox(String name, Set<Message> m) {
		this.name = name;
		messages = m;
	}
	
	public void move(Message m, Mailbox other) {
		other.messages.add(this.messages.remove(m));
	}
}