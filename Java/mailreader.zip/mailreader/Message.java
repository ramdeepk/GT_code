import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.Comparator;
import java.time.LocalDate;

public class Message implements Comparable<Message> {
	
    private String subject, message;
    private LocalDate date;
    private Person sender;
    private Set<Person> recipients;
	
    public Message(Person sender, String subject, String message) {
        this.sender = sender;
        this.subject = subject;
        this.message = message;
        this.date = LocalDate.now();
        this.recipients = new Set<Person>();
    }
	
	public Message(Person sender, String subject, String message, Set<Person> recipients) {
        this.sender = sender;
        this.subject = subject;
        this.message = message;
        this.date = LocalDate.now();
        this.recipients = recipients;
    }

    public int compareTo(Message m) {
        return this.date.compareTo(m.date);
    }

    public boolean equals(Object o) {
        if(o == null) {
			return false;
		} else {
			Message other = (Message) o;
			return this.sender.equals(other.sender)
				&& this.subject.equals(other.subject)
				&& this.message.equals(other.message)
				&& this.recipients.equals(other.recipients);
		}
    }
	
	public int hashCode() {
		int c = sender.hashCode() + subject.hashCode() + message.hashCode() + recipients.hashCode();
		return c;
	}
}