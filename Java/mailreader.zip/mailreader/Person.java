import java.util.Comparable;

public class Person implements Comparable<Person> {
	
    private String name, email;
	
    public Person(String name, String email) {
        this.name = name;
        this.email = email;
    }
	
    public int compareTo(Person other) {
        return this.name.compareTo(other.name);
    }
	
	public boolean equals(Object o) {
		if (o == null) { return false; }
		else {
			Person oth = (Person) o;
			return this.name.equals(oth.name) && this.email.equals(oth.email);
		}
	}
	
	public int hashCode() {
		int c = name.hashCode() + email.hashCode();
		return c; 
	}
}