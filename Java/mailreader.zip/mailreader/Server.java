import java.util.Random;
import java.util.ArrayList;

public class Server {
	
	public static Message generateMessage() {
		Random rand = new Random();
		//Library of senders, recipients, subjects, and messages
		Person[] senders = {new Person("Bruce Wayne", "batman@waynetech.com"),
			new Person("Tyrion Lannister", "midget@ironthrone.com"),
			new Person("Joe Schmoe", "average@generic.com"),
			new Person("Iggy Azalea", "sofancy@vevo.net"),
			new Person("Harry Potter", "itsmagic@chosenone.com"),
			new Person("Me", "me@myself.gov")};
		String[] subjects = {"OMG", "Respond ASAP", "Your job is on the line",
			"Congrats!", "We need to talk", "I think Voldemort's back",
			"25% off your next massage!"};
		String[] randMessages = {"Stand up. Your father's passing.",
			"It might be a tumor.", "There's no crying in baseball!",
			"Why does it cry, Sméagol?", "Inconceivable!"};
		
		//Generating the contents of the message
		Set<Person> rec = new Set<>();
		int x = rand.nextInt(6) + 1;
		for (int i = 1; i <= x; i++) {
			rec.add(senders[rand.nextInt(6)]);
		}
		Person sender = senders[rand.nextInt(6)];
		String subj = subjects[rand.nextInt(7)];
		String mess = randMessages[rand.nextInt(5)];
		
		return new Message(sender, subj, mess, rec);
	}
}